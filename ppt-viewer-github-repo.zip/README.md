# PPT/PDF Slide Viewer — GitHub-ready repo

This repository contains a single-page static app that lets you view slides from an unlocked PDF (exported from PowerPoint) or a set of slide images. It uses PDF.js and runs entirely in the browser (files stay local).

This repo also includes a GitHub Actions workflow that automatically publishes the site to **GitHub Pages** when you push to the `main` branch.

---

## Quick steps — create the repository and publish

1. **Create a new GitHub repository**
   - Go to https://github.com/new and create a repository (example name: `ppt-viewer-static`).
   - Do NOT initialize with README/license (we'll push an existing repo).

2. **Push these files from your local machine**
   ```bash
   git clone https://github.com/YOUR_USERNAME/YOUR_EMPTY_REPO.git
   cd YOUR_EMPTY_REPO
   # copy these files into the folder, or unzip the repo bundle here
   git add .
   git commit -m "Initial site"
   git branch -M main
   git push -u origin main
   ```

3. **Wait for GitHub Actions to run**
   - Open the **Actions** tab in your repository. You should see the `Deploy to GitHub Pages` workflow running after the push.
   - If it succeeds, it will create (or update) a `gh-pages` branch with the published content.

4. **View your site**
   - After a successful run, your site will be served from:
     ```
     https://YOUR_USERNAME.github.io/YOUR_REPO_NAME/
     ```
   - If the URL does not load, open **Settings → Pages** to check the selected branch (it should be `gh-pages` and folder `/ (root)`).

5. **Update the site**
   - Make changes (edit `index.html`), commit, and push to `main`. The workflow will run again and redeploy.

---

## Optional: Use a custom domain
- Add a `CNAME` file at the repository root containing your custom domain (e.g. `example.com`) and push it.
- Configure your DNS to point to GitHub Pages (A records or CNAME depending on setup).
- See GitHub docs for details: _Settings → Pages → Custom domain_.

---

## Troubleshooting
- If the action fails, open **Actions → build-and-deploy** and inspect the logs (the "Prepare public directory" and "Deploy" steps).
- Make sure the `main` branch exists and you're pushing to it.
- The workflow uses the automatically available `GITHUB_TOKEN` and does **not** require a personal access token.

---

If you want, I can:
- Create the repository on your GitHub account for you (I cannot do this directly without your credentials, but I can provide the exact `curl`/GitHub CLI commands).
- Add a custom domain/CNAME template.
- Add an automatic GitHub Release or versioned publishing step.
